package com.spring.exception;

public class UnavailableDishException extends Exception {

	public UnavailableDishException(String msg) {
		// Fill the code
		super(msg);
	}
}
