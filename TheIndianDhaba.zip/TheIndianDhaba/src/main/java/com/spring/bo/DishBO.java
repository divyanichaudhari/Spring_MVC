package com.spring.bo;

import java.util.Map;
import java.util.Map.Entry;

import org.springframework.stereotype.Component;

import com.spring.model.Dish;

//use appropriate annotation to make this class as component class
@Component
public class DishBO {

	public double calculateDishSalesAmount(Dish dishObj) {
		

		        int orderCount = dishObj.getOrderCount();
		        Double costPerOrder = dishObj.getDishDetails().get(dishObj.getName());

		        if (costPerOrder == null) {
		            costPerOrder = 0.0;
		        }

		        return costPerOrder * orderCount;
		    }
		}

	
		
//		double dishSalesAmount = 0;
//		
//		int orderCount = dishObj.getOrderCount();
//	// Fill the code
//		
//		//Map<String, Double> dishDetails = dishObj.getDishDetails();
//		
//		//String d = dishObj.getName();
//		
//		//double dishv = dishObj.getDishDetails().get(dishDetails.;
//		
//		Double dishv = dishObj.getDishDetails().get(dishObj.getName());
//		
//		if(dishv == null) {
//			dishv = 0.0;
//		}
//		
//		dishSalesAmount = dishv * orderCount;
//			
//		return dishSalesAmount;
//	}
//}
