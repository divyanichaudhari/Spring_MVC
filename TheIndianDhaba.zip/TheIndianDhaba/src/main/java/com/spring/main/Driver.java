package com.spring.main;

import java.util.Scanner;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.spring.config.ApplicationConfig;
import com.spring.exception.UnavailableDishException;
import com.spring.model.Dish;
import com.spring.service.DishService;

public class Driver {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        ApplicationContext context = new AnnotationConfigApplicationContext(ApplicationConfig.class);
        DishService dishService = context.getBean(DishService.class);
        
        // First dish details
        Dish firstDish = context.getBean(Dish.class);
        System.out.println("First dish details");
        System.out.print("Enter the dish name: ");
        firstDish.setName(sc.nextLine());
        System.out.print("Enter the number of orders taken for the dish: ");
        firstDish.setOrderCount(Integer.parseInt(sc.nextLine()));

        // Calculate bonus for first dish
        try {
            dishService.calculateDishSalesAmount(firstDish);
            System.out.println("The bonus amount from the " + firstDish.getName() + " dish is $" + firstDish.getBonusAmount());
        } catch (UnavailableDishException e) {
            System.out.println(e.getMessage());
        }

        // Second dish details
        Dish secondDish = context.getBean(Dish.class);
        System.out.println("Second dish details");
        System.out.print("Enter the dish name: ");
        secondDish.setName(sc.nextLine());
        System.out.print("Enter the number of orders taken for the dish: ");
        secondDish.setOrderCount(Integer.parseInt(sc.nextLine()));

        // Calculate bonus for second dish
        try {
            dishService.calculateDishSalesAmount(secondDish);
            System.out.println("The bonus amount from the " + secondDish.getName() + " dish is $" + secondDish.getBonusAmount());
        } catch (UnavailableDishException e) {
            System.out.println(e.getMessage());
        }

        sc.close();
    }
}
