package com.spring.model;

public interface Restaurant {

	public void calculateBonusAmount(double dishSalesAmount);
}
