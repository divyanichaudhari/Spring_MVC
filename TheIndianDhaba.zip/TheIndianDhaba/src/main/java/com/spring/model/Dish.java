package com.spring.model;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class Dish implements Restaurant {

    private String name;
    private int orderCount;
    private double bonusAmount;

    // Correctly use @Value for map
    @Value("#{${dishDetails.map}}")
    private Map<String, Double> dishDetails;

    // Correctly use @Value for percentage
    @Value("#{${percentage}}")
    private double percentage;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getOrderCount() {
        return orderCount;
    }

    public void setOrderCount(int orderCount) {
        this.orderCount = orderCount;
    }

    public double getBonusAmount() {
        return bonusAmount;
    }

    public void setBonusAmount(double bonusAmount) {
        this.bonusAmount = bonusAmount;
    }

    public Map<String, Double> getDishDetails() {
        return dishDetails;
    }

    public void setDishDetails(Map<String, Double> dishDetails) {
        this.dishDetails = dishDetails;
    }

    public double getPercentage() {
        return percentage;
    }

    public void setPercentage(double percentage) {
        this.percentage = percentage;
    }

    @Override
    public void calculateBonusAmount(double dishSalesAmount) {
        // Calculate bonus amount based on the sales amount and percentage
        bonusAmount = dishSalesAmount * percentage / 100;
    }
}
