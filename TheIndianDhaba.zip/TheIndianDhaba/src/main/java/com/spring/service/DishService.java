package com.spring.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.spring.bo.DishBO;
import com.spring.exception.UnavailableDishException;
import com.spring.model.Dish;

@Component
public class DishService {

    private DishBO dishBO;

    @Autowired
    public DishService(DishBO dishBO) {
        this.dishBO = dishBO;
    }

    public DishBO getDishBO() {
        return dishBO;
    }

    public void setDishBO(DishBO dishBO) {
        this.dishBO = dishBO;
    }

    public void calculateDishSalesAmount(Dish dishObj) throws UnavailableDishException {
        Map<String, Double> dishDetails = dishObj.getDishDetails();

        // Check if the dish name exists in the dish details
        if (!dishDetails.containsKey(dishObj.getName())) {
            throw new UnavailableDishException("This dish is not available");
        }

        // Get the cost per order from the dish details map
        double costPerOrder = dishDetails.get(dishObj.getName());

        // Calculate the total sales amount
        double dishSalesAmount = dishBO.calculateDishSalesAmount(dishObj);

        // Calculate the bonus amount
        dishObj.calculateBonusAmount(dishSalesAmount);
    }
}
