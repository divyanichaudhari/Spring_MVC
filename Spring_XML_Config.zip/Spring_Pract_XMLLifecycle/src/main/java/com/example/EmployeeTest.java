package com.example;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeTest {
	public static void main(String[] args) {
		AbstractApplicationContext ac = new ClassPathXmlApplicationContext("cofig.xml");
		Employee ee = (Employee) ac.getBean("emp");
		System.out.println(ee);
		ac.registerShutdownHook();
	}

}
