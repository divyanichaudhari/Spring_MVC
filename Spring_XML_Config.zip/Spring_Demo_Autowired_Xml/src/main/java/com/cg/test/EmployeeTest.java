package com.cg.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.beans.Employee;

public class EmployeeTest {

	public static void main(String[] args) {
		// for byName byType
		ApplicationContext ac = new ClassPathXmlApplicationContext("config.xml");
		Employee ee = (Employee)ac.getBean("addressId");
		ee.display();
		
		
	}
}
