package com.cg.example.Spring_XML_Config;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class EmployeeTest {

	public static void main(String[] args) {
		ApplicationContext ac = new ClassPathXmlApplicationContext("BeanConfig.xml");
		 Employee ee=(Employee) ac.getBean("emp");
		 System.out.println(ee);
		 
		 ApplicationContext app = new ClassPathXmlApplicationContext("BeanConfig.xml");
		 Department dd = (Department) app.getBean("dept");
		 System.out.println(dd);
	}
}
