package com.cg.example.Spring_XML_Config;

public class Department {

	private int deptid;
	private String dname;
	private String location;
	
	@Override
	public String toString() {
		return "Department [deptid=" + deptid + ", dname=" + dname + ", location=" + location + "]";
	}

	public Department(int deptid, String dname, String location) {
		super();
		this.deptid = deptid;
		this.dname = dname;
		this.location = location;
	}
	
	
	
}
